# This code simply runs stack-test (identical to stack-root but memory addresses
# are printed for info) a certain number of times. 'buffoverflow.py' must be modified
# to contain correct parts of the return address first (see 'buffoverflow.py' for
# details.


import os

iterations = 1000 # No of iterations

i = 0
while i < iterations:
	os.system('./stack-test')
	i += 1
	
