FORMAT STRING LAB01 readme.txt

This directory contains example solutions to each of the tasks 
set for the Format String Attack laboratory. They are designed
to be run from the vagrant virtual machines provided from the 
Prelab work.

The requisite software/modules to run them are Python2 and the 
'pexpect' python module. These should be installed automatically
by vagrant.

Each of the .py scripts contain very brief descriptions of how 
they work and what they attempt to show, but for a full 
description of how the format string exploits are carried out,
please refer to the technical report.
